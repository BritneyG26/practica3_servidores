from flask import render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, current_user
from werkzeug.exceptions import BadRequest, Unauthorized
from . import bp
from ...extensions import db
from ...schemas.usuario import usuario_schema, usuarios_schema
from ...schemas.login import login_schema
from app.models.usuario import Usuario


# ---- Vistas (HTML) ----
@bp.get("/login")
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    return render_template("login.html")


@bp.post("/login")
def login_post():
    data = request.form.to_dict()
    errors = login_schema.validate(data)
    if errors:
        flash("Datos inválidos", "error")
        return render_template("login.html", errors=errors, form=data), 400

    user = Usuario.query.filter_by(email=data["email"]).first()
    if not user or not user.check_password(data["password"]):
        flash("Usuario o contraseña incorrectos", "error")
        return render_template("login.html", form=data), 401

    login_user(user)
    return redirect(url_for("main.dashboard"))


@bp.get("/logout")
def logout():
    if current_user.is_authenticated:
        logout_user()
    return redirect(url_for("auth.login"))


# ---- API ----
@bp.post("/api/v1/auth/login")
def api_login():
    """
    Autenticación de usuario.
    ---
    tags:
      - auth
    summary: Login de usuario
    description: Valida credenciales de usuario y crea sesión (cookie de sesión).
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            properties:
              username:
                type: string
              password:
                type: string
                format: password
            required: [username, password]
    responses:
      200:
        description: Login exitoso
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                user:
                  $ref: '#/components/schemas/User'
      400:
        description: Datos inválidos
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Error'
      401:
        description: Credenciales inválidas
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Error'
    """
    if not request.is_json:
        raise BadRequest("Se requiere JSON")

    payload = request.get_json() or {}
    errors = login_schema.validate(payload)
    if errors:
        return jsonify({"error": "Bad Request", "message": errors}), 400

    user = Usuario.query.filter_by(email=payload["email"]).first()
    if not user or not user.check_password(payload["password"]):
        raise Unauthorized("Credenciales inválidas")

    login_user(user)
    return jsonify({"message": "ok", "user": usuario_schema.dump(user)}), 200


@bp.post("/api/v1/auth/logout")
def api_logout():
    """
    Cierra la sesión del usuario autenticado.
    ---
    tags:
      - auth
    responses:
      200:
        description: Sesión cerrada
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
    """
    if current_user.is_authenticated:
        logout_user()
    return jsonify({"message": "logged out"}), 200
