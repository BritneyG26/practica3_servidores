from flask import render_template, redirect, url_for, jsonify
from flask_login import login_required, current_user
from . import bp
from ...schemas.usuario import usuario_schema


@bp.get("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    return redirect(url_for("auth.login"))


@bp.get("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html")


@bp.get("/api/v1/users/me")
@login_required
def me():
    """
    Devuelve el usuario autenticado.
    ---
    tags:
      - users
    responses:
      200:
        description: Usuario autenticado
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/User'
      401:
        description: No autenticado
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Error'
    """
    return jsonify(user_schema.dump(current_user)), 200
