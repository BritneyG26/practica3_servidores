import click
from getpass import getpass
from .extensions import db
from .models.usuario import Usuario


def register_cli(app):
    @app.cli.command("create-user")
    @click.option("--nombre", prompt=True)
    @click.option("--email", prompt=True)
    @click.option("--password", prompt=False, hide_input=True)
    def create_user(nombre, email, password):
        """Crea un usuario en la base de datos."""
        if not password:
            password = getpass("Password: ")
        with app.app_context():
            if Usuario.query.filter((Usuario.nombre == nombre) | (Usuario.email == email)).first():
                click.echo("Usuario o email ya existe")
                return
            u = Usuario(nombre=nombre, email=email)
            u.set_password(password)
            db.session.add(u)
            db.session.commit()
            click.echo(f"Usuario creado: {u.nombre} ({u.email})")
