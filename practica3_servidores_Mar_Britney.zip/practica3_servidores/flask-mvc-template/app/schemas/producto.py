from flask_marshmallow import Marshmallow
from marshmallow import fields, validate, ValidationError
from ..extensions import ma


class ProductoSchema(ma.Schema):
    id = fields.Int(dump_only=True)
    nombre = fields.Str(required=True, validate=validate.Length(min=1, max=200))
    descripcion = fields.Str()
    precio = fields.Float(required=True, validate=validate.Range(min=0))
    stock = fields.Int(validate=validate.Range(min=0))
    usuario_id = fields.Int(required=True)
    created_at = fields.DateTime(dump_only=True)
    
    class Meta:
        fields = ('id', 'nombre', 'descripcion', 'precio', 'stock', 'usuario_id', 'created_at')


producto_schema = ProductoSchema()
productos_schema = ProductoSchema(many=True)