from flask import request, jsonify, render_template
from werkzeug.exceptions import HTTPException
import structlog

log = structlog.get_logger()


def register_error_handlers(app):
    @app.errorhandler(HTTPException)
    def handle_http_exception(err: HTTPException):
        log.warning("http_exception", status=err.code, name=err.name, description=err.description)
        if _wants_json():
            return jsonify({"error": err.name, "message": err.description}), err.code
        # Render genérico para vistas
        return render_template("error.html", status=err.code, error=err.name, message=err.description), err.code

    @app.errorhandler(Exception)
    def handle_exception(err: Exception):
        log.exception("unhandled_exception")
        if _wants_json():
            return jsonify({"error": "Internal Server Error", "message": "Unexpected error"}), 500
        return render_template("error.html", status=500, error="Internal Server Error", message="Unexpected error"), 500


def _wants_json() -> bool:
    # Si la ruta inicia con /api o acepta application/json
    if request.path.startswith("/api"):
        return True
    best = request.accept_mimetypes.best_match(["application/json", "text/html"])
    return best == "application/json" and request.accept_mimetypes[best] > request.accept_mimetypes["text/html"]
