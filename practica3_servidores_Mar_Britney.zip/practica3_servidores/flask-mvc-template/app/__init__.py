import os
from flask import Flask
from dotenv import load_dotenv
from .extensions import db, migrate, login_manager, ma
from .utils.logging import configure_logging
from .utils.errors import register_error_handlers
from .config import Config


def create_app(config_name: str | None = None) -> Flask:
    """Aplicación Flask usando App Factory pattern."""
    load_dotenv()

    if config_name is None:
        config_name = os.getenv("FLASK_ENV", "development")

    app = Flask(__name__, instance_relative_config=True, static_folder="static", template_folder="templates")
    os.makedirs(app.instance_path, exist_ok=True)
    app.config.from_object(Config)

    # Logging estructurado
    configure_logging(app)

    # Extensiones
    db.init_app(app)
    ma.init_app(app)
    migrate.init_app(app, db)

    from .cli import register_cli
    register_cli(app)

    # Flask-Login
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    from .models.usuario import Usuario

    @login_manager.user_loader
    def load_user(user_id):
        return Usuario.query.get(int(user_id))


    # CORS opcional (solo /api/*)
    _maybe_enable_cors(app)

    # Swagger UI (Flasgger)
    _init_swagger(app)

    # Blueprints
    _register_blueprints(app)
    return app

    # Manejadores de errores
    register_error_handlers(app)

    # User loader
    from .models.user import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    return app


def _maybe_enable_cors(app: Flask) -> None:
    origins = app.config.get("CORS_ORIGINS", "")
    enable = bool(origins) or app.config.get("ENABLE_CORS", False)
    if enable:
        from flask_cors import CORS
        if origins.strip() == "*":
            CORS(app, resources={r"/api/*": {"origins": "*"}})
        else:
            allowed = [o.strip() for o in origins.split(",") if o.strip()]
            CORS(app, resources={r"/api/*": {"origins": allowed}})


def _init_swagger(app: Flask) -> None:
    from flasgger import Swagger
    app.config["SWAGGER"] = {
        "title": os.getenv("SWAGGER_TITLE", "Flask MVC Template"),
        "uiversion": 3,
        "openapi": "3.0.2",
    }
    swagger_template = {
        "openapi": "3.0.2",
        "info": {
            "title": os.getenv("SWAGGER_TITLE", "Flask MVC Template"),
            "version": os.getenv("SWAGGER_VERSION", "1.0.0"),
        },
        "components": {
            "schemas": {
                "User": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "integer"},
                        "username": {"type": "string"},
                        "email": {"type": "string", "format": "email"},
                        "created_at": {"type": "string", "format": "date-time"},
                    },
                },
                "Error": {
                    "type": "object",
                    "properties": {
                        "error": {"type": "string"},
                        "message": {"type": "string"},
                    },
                },
            }
        },
    }
    Swagger(app, template=swagger_template)


def _register_blueprints(app: Flask) -> None:
    from .blueprints.auth import bp as auth_bp
    from .blueprints.main import bp as main_bp
    from .blueprints.health import bp as health_bp
    from .blueprints.usuarios.routes import bp as usuarios_bp
    from .blueprints.productos.routes import bp as productos_bp

    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(main_bp)
    app.register_blueprint(health_bp, url_prefix="/health")
    app.register_blueprint(usuarios_bp, url_prefix="/api")   
    app.register_blueprint(productos_bp, url_prefix="/api")
